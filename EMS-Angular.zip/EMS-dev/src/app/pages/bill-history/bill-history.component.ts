import { Router } from '@angular/router';
import { CommonModule, Location } from '@angular/common';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IBill, IViewBill } from '../../interfaces/bills';
// import { Router } from '../../../../node_modules/@angular/router/index';
import { ApiService } from '../../service/api.service';
import { UserType } from '../../interfaces/users';
import { Component } from '@angular/core';


@Component({
  selector: 'app-bill-history',
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './bill-history.component.html',
  styleUrl: './bill-history.component.scss',
})
export class BillHistoryComponent {
  // constructor(private readonly location: Location) {}
  constructor(
    private router: Router,
    private location: Location,
    private apiService: ApiService
  ) {}
  billsPaid: IViewBill[] = [];
  currentUser = JSON.parse(localStorage.getItem('user') as string);

  // Sample data for bills


  filteredBills = [...this.billsPaid];
  totalAmount = 0;
  startDate = new FormControl(new Date());
  endDate = new FormControl(new Date());
  loading = false;
  errorMessage = '';
  paymentStatusFilter = '';


  ngOnInit(): void {
    this.getAllPaidBills();
    if (this.currentUser.role === UserType.CUSTOMER) {
      this.apiService.getAllPaidBills(this.currentUser.customerId).subscribe({
        next: (value) => {
          // ?? Avoid returning a plain string when no data is found; it's not a good practice for server responses.
          if (typeof value !== 'string') {
            this.billsPaid = value as IViewBill[];
            console.log(value);
          }
        },
      });
    } else if (this.currentUser.role === UserType.ADMIN) {
      this.apiService.getAdminAllBills().subscribe({
        next: (value)=> {
          // ?? Avoid returning a plain string when no data is found; it's not a good practice for server responses.
          if (typeof value !== 'string') {
            this.billsPaid = value as IViewBill[];
            if(this.billsPaid == null) {
              
            }
            console.log(value);
          }
        }
      })
    }
  }


getAllPaidBills(): void {
    this.loading = true;
    if (this.startDate === null) {
      return;
    }
    this.loading = false;
  }

  sortBills(criteria: string): void {
    this.billsPaid = (this.billsPaid as any).sort((a: any, b: any) =>
      a[criteria as any] > b[criteria] ? 1 : -1
    );
  }

  

  downloadBill(billId: string): void {
    // Simulate downloading a PDF or other file format
    alert('Downloading Bill ' + billId);
  }

  handleBack(){
    this.location.back()
  }
}


