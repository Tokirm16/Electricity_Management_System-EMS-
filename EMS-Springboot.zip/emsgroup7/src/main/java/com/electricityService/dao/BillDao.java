package com.electricityService.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.electricityService.bean.Bill;
import com.electricityService.controller.PaymentRequestDto;
import com.electricityService.service.CustomerService;
import com.electricityService.util.DBUtil;

public class BillDao {

	// get all bills of customerId
	public ArrayList<Bill> getAllBillsOfConsumer(String customer_id) throws SQLException {

		Connection cn = DBUtil.toConnect();
		ArrayList<Bill> bills = new ArrayList<>();
		PreparedStatement ps = null;
		long cid = 0;
		if (customer_id == null) {
			return null;
		} else {
			cid = Long.parseLong(customer_id);
		}

		String query = "SELECT b.bill_number, b.consumer_id, b.bill_date, b.due_date, b.bill_amount, b.payable_amount, b.payment_status, b.electricity_usage\r\n"
				+ "FROM Bills b\r\n" + "JOIN Consumers c ON b.consumer_id = c.consumer_id\r\n"
				+ "JOIN Customers cus ON c.customer_id = cus.customer_id\r\n"
				+ "WHERE cus.customer_id = ? AND b.payment_status = 0\r\n";
		ps = cn.prepareStatement(query);
		ps.setLong(1, cid);

		ResultSet rs;

		rs = ps.executeQuery();

		while (rs.next()) {
			bills.add(new Bill(rs.getLong("bill_number"), rs.getLong("consumer_id"), rs.getString("bill_date"),
					rs.getString("due_date"), rs.getDouble("bill_amount"), rs.getDouble("payable_amount"),
					rs.getInt("payment_status"), rs.getDouble("electricity_usage")));
		}
		DBUtil.toClose(cn, ps, rs);
		return bills;

	}

	// get all Paid bills of customerId
	public ArrayList<Bill> viewPaidBillByCustId(String customer_id) throws SQLException {

		Connection cn = DBUtil.toConnect();
		ArrayList<Bill> bills = new ArrayList<>();
		PreparedStatement ps = null;
		long cid = 0;
		if (customer_id == null) {
			return null;
		} else {
			cid = Long.parseLong(customer_id);
		}

		String query = "SELECT b.bill_number, b.consumer_id, b.bill_date, b.due_date, b.bill_amount, p.payment_date, p.payment_mode, b.payable_amount, b.payment_status,"
				+ " b.electricity_usage\r\n"
				+ "FROM Bills b\r\n" 
				+ "JOIN Consumers c ON b.consumer_id = c.consumer_id\r\n"
				+ "JOIN Payments p ON b.bill_number = p.bill_number\r\n"
				+ "JOIN Customers cus ON c.customer_id = cus.customer_id\r\n"
				+ "WHERE cus.customer_id = ? AND b.payment_status = 1 \r\n";
		ps = cn.prepareStatement(query);
		ps.setLong(1, cid);

		ResultSet rs;

		rs = ps.executeQuery();

		while (rs.next()) {
			bills.add(new Bill(rs.getLong("bill_number"), rs.getLong("consumer_id"), rs.getString("bill_date"),
					rs.getString("due_date"), rs.getDouble("bill_amount"), rs.getDouble("payable_amount"),
					rs.getInt("payment_status"), rs.getString("payment_date"), rs.getString("payment_mode"),
					rs.getDouble("electricity_usage")));
		}
		DBUtil.toClose(cn, ps, rs);
		return bills;

	}

	// get current bill summary
	public Bill getCurrentBillSummary(String customer_id) throws SQLException {

		Connection cn = DBUtil.toConnect();
		PreparedStatement ps = null;
		Bill bill = null;

		long cid = Long.parseLong(customer_id);

		String query = "SELECT b.bill_number, b.consumer_id, b.bill_date, b.due_date, b.bill_amount, b.payable_amount, b.payment_status, b.electricity_usage\r\n"
				+ "FROM Bills b\r\n" + "JOIN Consumers c ON b.consumer_id = c.consumer_id\r\n"
				+ "JOIN Customers cus ON c.customer_id = cus.customer_id\r\n" + "WHERE cus.customer_id = ?\r\n"
				+ "AND b.payment_status = 0 ORDER BY b.due_date ASC FETCH FIRST 1 ROWS ONLY";
		ps = cn.prepareStatement(query);
		ps.setLong(1, cid);

		ResultSet rs = ps.executeQuery();

		while (rs.next()) {
			bill = new Bill(rs.getLong("bill_number"), rs.getLong("consumer_id"), rs.getString("bill_date"),
					rs.getString("due_date"), rs.getDouble("bill_amount"), rs.getDouble("payable_amount"),
					rs.getInt("payment_status"), rs.getDouble("electricity_usage"));
		}
		DBUtil.toClose(cn, ps, rs);
		return bill;
	}

	// process payment
	public List<String> processPayment(PaymentRequestDto paymentRequest) throws SQLException {

		Connection cn = DBUtil.toConnect();
		PreparedStatement ps = null;
		int rs = 0;

		// Backend Validations for payment
		String payment_mode = paymentRequest.getPaymentMode();
		long billNumber = paymentRequest.getBillNumber();
		double payable_amount = paymentRequest.getPayableAmount();

		if ((payment_mode == "") || (billNumber == 0) || (payable_amount == 0)) {
			return null;
		}

		String transaction_id = CustomerService.generateUniqueID();
		String payment_date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

//		for(Long bill_no: billNumbers) {

		String payment_id = CustomerService.generateUniqueID();

//			 (payment_id BigINT PRIMARY KEY,bill_number BIGINT NOT NULL,payment_date DATE NOT NULL,
//			payment_mode VARCHAR(20) CHECK (payment_mode IN ('Credit Card', 'Debit Card', 'Net Banking')) NOT NULL,
//			transaction_id VARCHAR(50) UNIQUE NOT NULL,payment_amount DECIMAL(10, 2) 

		String query = "INSERT INTO PAYMENTS(payment_id, bill_number, payment_date, payment_mode, transaction_id, payment_amount) VALUES(?, ?, ?, ?, ?, ?)";
		ps = cn.prepareStatement(query);
		ps.setLong(1, Long.parseLong(payment_id));
		ps.setLong(2, billNumber);
		ps.setString(3, payment_date);
		ps.setString(4, payment_mode);
		ps.setLong(5, Long.parseLong(transaction_id));
		ps.setDouble(6, payable_amount);

		rs = ps.executeUpdate();

//		}

		if (rs >= 1) {
//			for(Long bill_no: billNumbers) {

			String q = "UPDATE BILLS SET payment_status = 1 WHERE bill_number = ?";
			ps = cn.prepareStatement(q);
			ps.setLong(1, billNumber);

			rs = ps.executeUpdate();
		}

		List<String> resp = new ArrayList<>();
		resp.add(transaction_id);
		resp.add(payment_date);

		DBUtil.toClose(cn, ps, null);
		return resp;

	}

	// method to add Bill for Admin
	public String addBill(Bill bill) throws SQLException {

		Connection cn = DBUtil.toConnect();
		PreparedStatement ps = null;
		int rs = 0;

//		bill_number bigint primary key, consumer_id bigint, bill_date DATE NOT NULL, due_date DATE NOT NULL, bill_amount DECIMAL(10, 2) NOT NULL, payable_amount DECIMAL(10, 2) NOT NULL, payment_status int default 0,pg_charge REAL,electricity_usage REAL NOT NULL DEFAULT 0.02,FOREIGN KEY (consumer_id) REFERENCES Consumers(consumer_id))");

		String bill_id = CustomerService.generateUniqueID();

		String query = "INSERT INTO BILLS (bill_number, consumer_id, bill_date, due_date, bill_amount, payable_amount, payment_status, electricity_usage) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
		ps = cn.prepareStatement(query);
		ps.setLong(1, Long.parseLong(bill_id));
		ps.setLong(2, bill.getConsumerId());
		ps.setString(3, bill.getBillDate());
		ps.setString(4, bill.getDueDate());
		ps.setDouble(5, bill.getBillAmount());
		ps.setDouble(6, bill.getPayableAmount());
		ps.setInt(7, bill.getPaymentStatus());
		ps.setDouble(8, bill.getElectricityUsage());

		rs = ps.executeUpdate();

		DBUtil.toClose(cn, ps, null);

		if (rs >= 1)
			return bill_id;

		return null;
	}

	// get all bills for Admin
	public ArrayList<Bill> getAllBills() throws SQLException {

		Connection cn = DBUtil.toConnect();
		ArrayList<Bill> bills = new ArrayList<>();
		PreparedStatement ps = null;

		String query = "SELECT * FROM BILLS ORDER BY bill_date DESC";
		ps = cn.prepareStatement(query);
		ResultSet rs = ps.executeQuery();

		while (rs.next()) {

//			long billNumber, long consumerId, String billDate, String dueDate, double billAmount,
//			double payableAmount, String paymentStatus, String paymentDate, double electricityUsage

			bills.add(new Bill(rs.getLong("bill_number"), rs.getLong("consumer_id"), rs.getString("bill_date"),
					rs.getString("due_date"), rs.getDouble("bill_amount"), rs.getDouble("payable_amount"),
					rs.getInt("payment_status"), rs.getDouble("electricity_usage")));
		}
		DBUtil.toClose(cn, ps, rs);
		return bills;
	}

}
