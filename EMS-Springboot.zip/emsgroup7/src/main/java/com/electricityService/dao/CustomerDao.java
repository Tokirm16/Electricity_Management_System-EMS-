package com.electricityService.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.electricityService.bean.Customer;
import com.electricityService.controller.ResponseAddNewConsumer;
import com.electricityService.service.CustomerService;
import com.electricityService.util.DBUtil;

public class CustomerDao {

	// method to insert value into customer table
	public String insertValues(Customer c) throws SQLException {
		int res;

		String customer_id = CustomerService.generateUniqueID();

		Connection cn = DBUtil.toConnect();
		PreparedStatement ps = cn.prepareStatement("insert into Customers values (?,?,?,?,?,?,?,?)");
		ps.setLong(1, Long.parseLong(customer_id));
		ps.setString(2, c.getName());
		ps.setString(3, c.getAddress());
		ps.setString(4, c.getEmail());
		ps.setString(5, c.getMobileNumber());
		ps.setString(6, c.getCustomerType());
		ps.setString(7, c.getUserId());
		ps.setString(8, c.getPassword());
		res = ps.executeUpdate();

		if (res > 0)
			return customer_id;
		DBUtil.toClose(cn, ps, null);
		return null;
	}

	public Customer login(String userId, String password) throws SQLException {

		Connection cn = DBUtil.toConnect();
		Customer customer = new Customer();

		PreparedStatement ps = cn.prepareStatement("select * from customers where user_id=? and password =?");
		ps.setString(1, userId);
		ps.setString(2, password);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {

			// Customer(long customerId, String name, String address, String email, String
			// mobileNumber,String customerType, String userId)
			customer = new Customer(rs.getLong("customer_id"), rs.getString("name"), rs.getString("address"),
					rs.getString("email"), rs.getString("mobile_number"), rs.getString("customer_type"),
					rs.getString("user_id"));

		}

		DBUtil.toClose(cn, ps, rs);
		if(customer.getCustomerId() == 0) return null;
		return customer;
	}

	public static boolean isUserIdExist(String userId) throws SQLException {
		Connection cn = DBUtil.toConnect();
		PreparedStatement ps = cn.prepareStatement("Select * from Customers where user_id=?");
		ps.setString(1, userId);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			DBUtil.toClose(cn, ps, rs);
			return true;
		} else {
			DBUtil.toClose(cn, ps, rs);
			return false;
		}

	}

//		public ArrayList<Customer> fetch() throws SQLException {
//			ArrayList<Customer> c = new ArrayList<>();
//			Connection cn = DBUtil.toConnect();
//			PreparedStatement ps = cn.prepareStatement("Select * from Customer");
//			ResultSet rs= ps.executeQuery();
//			while(rs.next()) {
//				//Customer cus = new Customer(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
//				//c.add(cus);
//			}
//			if(c!= null || !c.isEmpty()) {
//				System.out.println("customers not null in dao");
//			}
//			DBUtil.toClose(cn, ps, rs);
//			return c;
//		}
//		public int delete(int cid) throws SQLException {
//			int res;
//
//			Connection cn = DBUtil.toConnect();
//			PreparedStatement ps = cn.prepareStatement("delete from customer where customer_id=?");
//			ps.setInt(1, cid);
//			res = ps.executeUpdate();
//
//			DBUtil.toClose(cn, ps, null);
//			return res;
//		}
	public Customer search(String search_criteria) throws SQLException {

		Connection cn = DBUtil.toConnect();
		Customer cus = null;
		PreparedStatement ps = null;
		if (search_criteria.matches("\\d+")) {
			long cid = Long.parseLong(search_criteria);
			ps = cn.prepareStatement("select * from customers where customer_id=? ");
			ps.setLong(1, cid);
		} else {
			ps = cn.prepareStatement("select * from customers where  name=? ");
			ps.setString(1, search_criteria);
		}

		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			// customer_id bigint PRIMARY KEY,name VARCHAR(50) NOT NULL,address VARCHAR(255)
			// NOT NULL,email VARCHAR(100) UNIQUE NOT NULL,mobile_number VARCHAR(15) NOT
			// NULL,customer_type VARCHAR(20) not null CHECK (customer_type
			// IN('Residential','Commercial')) NOT NULL,user_id VARCHAR(20) UNIQUE NOT
			// NULL,password VARCHAR(255)
			cus = new Customer(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
					rs.getString(6), rs.getString(7));
		}
		DBUtil.toClose(cn, ps, rs);
		return cus;
	}

	public ResponseAddNewConsumer getAllConsumersWithCustomer(String searchCriteria) throws SQLException {
	    Connection cn = DBUtil.toConnect();
	    ResponseAddNewConsumer response = null;
	    PreparedStatement psCustomer = null;
	    PreparedStatement psConsumers = null;
	    ResultSet rsCustomer = null;
	    ResultSet rsConsumers = null;

	    try {
	        // Step 1: Fetch customer details based on search criteria
	        if (searchCriteria.matches("\\d+")) { // If searchCriteria is a number
	            long cid = Long.parseLong(searchCriteria);
	            psCustomer = cn.prepareStatement("SELECT * FROM Customers WHERE customer_id = ?");
	            psCustomer.setLong(1, cid);
	        } else { // If searchCriteria is a name
	            psCustomer = cn.prepareStatement("SELECT * FROM Customers WHERE name = ?");
	            psCustomer.setString(1, searchCriteria);
	        }
	        rsCustomer = psCustomer.executeQuery();

	        // If customer found, initialize ResponseAddNewConsumer
	        if (rsCustomer.next()) {
	            long customerId = rsCustomer.getLong("customer_id");
	            String name = rsCustomer.getString("name");
	            String address = rsCustomer.getString("address");
	            String email = rsCustomer.getString("email");
	            String mobileNumber = rsCustomer.getString("mobile_number");
	            String customerType = rsCustomer.getString("customer_type");
	            String userId = rsCustomer.getString("user_id");
	            String password = rsCustomer.getString("password");

	            // Step 2: Fetch all consumers for the customer
	            psConsumers = cn.prepareStatement("SELECT consumer_id FROM Consumers WHERE customer_id = ?");
	            psConsumers.setLong(1, customerId);
	            rsConsumers = psConsumers.executeQuery();

	            ArrayList<Long> allConsumers = new ArrayList<>();
	            while (rsConsumers.next()) {
	                allConsumers.add(rsConsumers.getLong("consumer_id"));
	            }

	            // Step 3: Populate the ResponseAddNewConsumer object
	            response = new ResponseAddNewConsumer(
	                customerId, name, address, email, mobileNumber,
	                customerType, userId, password, allConsumers
	            );
	        }
	    } finally {
	        // Close all resources
	        DBUtil.toClose(cn, psCustomer, rsCustomer);
	        if (psConsumers != null) psConsumers.close();
	        if (rsConsumers != null) rsConsumers.close();
	    }
	    return response;
	}

}
