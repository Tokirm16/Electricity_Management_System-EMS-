package com.electricityService.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.electricityService.bean.Complaint;
import com.electricityService.service.CustomerService;
import com.electricityService.util.DBUtil;

public class ComplaintDao {

	public String registerComplaint(Complaint complaint) throws SQLException {
		
		Connection cn = DBUtil.toConnect();
		int rs = 0;

		String complaint_id = CustomerService.generateCompID();

		String query = "INSERT  INTO COMPLAINTS(complaint_id, consumer_id, complaint_type, category, description, landmark, mobile_number, status)  VALUES(?, ? , ?, ?, ?, ?, ?, ?)";
		PreparedStatement ps = cn.prepareStatement(query);
		ps.setInt(1, Integer.parseInt(complaint_id));
		ps.setLong(2, complaint.getConsumerId());
		ps.setString(3, complaint.getComplaintType());
		ps.setString(4, complaint.getCategory());
		ps.setString(5, complaint.getDescription());
		ps.setString(6, complaint.getLandmark());
		ps.setString(7, complaint.getMobileNumber());
		ps.setString(8, "Pending");
		rs = ps.executeUpdate();

		DBUtil.toClose(cn, ps, null);

		if (rs >= 1)
			return complaint_id;
		return null;
	}

	
	
	public ArrayList<Complaint> viewComplaints(String customer_id) throws SQLException {
		Connection cn = DBUtil.toConnect();
		ArrayList<Complaint> complaints = new ArrayList<>();
		PreparedStatement ps = null;

		long cid = Long.parseLong(customer_id);
		String query = "SELECT b.complaint_id, b.consumer_id, b.complaint_type, b.status, b.date_registered, b.resolution_time \r\n"
				+ "FROM Complaints b\r\n"
				+ "JOIN Consumers c ON b.consumer_id = c.consumer_id\r\n"
				+ "JOIN Customers cus ON c.customer_id = cus.customer_id\r\n"
				+ "WHERE cus.customer_id = ?\r\n";
		ps = cn.prepareStatement(query);
		ps.setLong(1, cid);

		ResultSet rs = ps.executeQuery();
		
		while (rs.next()) {
			complaints.add(new Complaint(rs.getInt("complaint_id"), rs.getLong("consumer_id"), rs.getString("complaint_type"), rs.getString("status"), rs.getString("date_registered"), rs.getString("resolution_time")));
		}
		DBUtil.toClose(cn, ps, rs);
		return complaints;

	}
}
