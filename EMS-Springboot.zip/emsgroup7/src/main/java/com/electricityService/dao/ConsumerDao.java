package com.electricityService.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.electricityService.bean.Consumer;
import com.electricityService.util.DBUtil;

public class ConsumerDao {

	public ArrayList<Consumer> fetch() throws SQLException {
		ArrayList<Consumer> c = new ArrayList<>();
		Connection cn = DBUtil.toConnect();
		PreparedStatement ps = cn.prepareStatement("Select * from Consumers");
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			Consumer cus = new Consumer(rs.getLong(1), rs.getLong(2), rs.getString(3), rs.getString(4),
					rs.getString(5));
			c.add(cus);
		}

		DBUtil.toClose(cn, ps, rs);
		return c;
	}

	public ArrayList<Consumer> consumerSearch(long customerId) throws SQLException {
		ArrayList<Consumer> c = new ArrayList<>();
		Connection cn = DBUtil.toConnect();
		PreparedStatement ps = cn.prepareStatement("Select * from Consumers where customer_id=?");
		ps.setLong(1, customerId);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			c.add(new Consumer(rs.getLong(1), rs.getLong(2), rs.getString(3), rs.getString(4), rs.getString(5)));

		}
		return c;
	}

	public int addConsumer(Consumer c) throws SQLException {
		int res = 0;

		Connection cn = DBUtil.toConnect();
		PreparedStatement ps = cn.prepareStatement("insert into Consumers values (?,?,?,?,?)");
		ps.setLong(1, c.getConsumerId());
		ps.setLong(2, c.getCustomerId());
		ps.setString(3, c.getAddress());
		ps.setString(4, c.getMobileNumber());
		ps.setString(5, c.getCustomerType());
		res = ps.executeUpdate();

		DBUtil.toClose(cn, ps, null);

		return res;
	}

	public ArrayList<Consumer> getAllConsumer(String customer_id) throws SQLException {
		Connection cn = DBUtil.toConnect();
		ArrayList<Consumer> consumers = new ArrayList<>();
		PreparedStatement ps = null;
		long cid = 0;
		if (customer_id == null) {

		}
		else {
			 cid = Long.parseLong(customer_id);
		}

		/*
		 * bill_number bigint primary key, consumer_id bigint, bill_date DATE NOT NULL,
		 * due_date DATE NOT NULL, bill_amount DECIMAL(10, 2) NOT NULL, payable_amount
		 * DECIMAL(10, 2) NOT NULL, payment_status int default 0, pg_charge
		 * REAL,electricity_usage REAL NOT NULL DEFAULT 0.02,FOREIGN KEY (consumer_id)
		 * REFERENCES Consumers(consumer_id))");
		 **/

		String query = "SELECT* from consumers where customer_id =? and isActive =1";
		ps = cn.prepareStatement(query);
		ps.setLong(1, cid);

		ResultSet rs;

		rs = ps.executeQuery();

		while (rs.next()) {

			// consumer_id bigint PRIMARY KEY,customer_id bigint NOT NULL,
			// address VARCHAR(255) NOT NULL,contact_number VARCHAR(15) NOT NULL,
			// customer_type VARCHAR(20) CHECK (customer_type IN ('Residential',
			// 'Commercial')) NOT NULL,FOREIGN
			consumers.add(new Consumer(rs.getLong("consumer_id"), rs.getLong("customer_id"), rs.getString("address"),
					rs.getString("contact_number"), rs.getString("customer_type")));
		}
		DBUtil.toClose(cn, ps, rs);
		return consumers;
	}

	
	
	
	public ArrayList<Consumer> getAllConsumer() throws SQLException {
		Connection cn = DBUtil.toConnect();
		ArrayList<Consumer> consumers = new ArrayList<>();
		PreparedStatement ps = null;
	


		String query = "SELECT* from consumers where isActive =1";
		ps = cn.prepareStatement(query);

		ResultSet rs;

		rs = ps.executeQuery();

		while (rs.next()) {

			// consumer_id bigint PRIMARY KEY,customer_id bigint NOT NULL,
			// address VARCHAR(255) NOT NULL,contact_number VARCHAR(15) NOT NULL,
			// customer_type VARCHAR(20) CHECK (customer_type IN ('Residential',
			// 'Commercial')) NOT NULL,FOREIGN
			consumers.add(new Consumer(rs.getLong("consumer_id"), rs.getLong("customer_id"), rs.getString("address"),
					rs.getString("contact_number"), rs.getString("customer_type")));
		}
		DBUtil.toClose(cn, ps, rs);
		return consumers;
	}

public ArrayList<Long> getAllConsumerId(String customerId) throws SQLException  {
	Connection cn = DBUtil.toConnect();
	ArrayList<Long> consId = new ArrayList<>();
	PreparedStatement ps = null;
	long cid = 0;
	if (customerId == null) {

	}
	else {
	cid = Long.parseLong(customerId);
	}
	/*
	 * bill_number bigint primary key, consumer_id bigint, bill_date DATE NOT NULL,
	 * due_date DATE NOT NULL, bill_amount DECIMAL(10, 2) NOT NULL, payable_amount
	 * DECIMAL(10, 2) NOT NULL, payment_status int default 0, pg_charge
	 * REAL,electricity_usage REAL NOT NULL DEFAULT 0.02,FOREIGN KEY (consumer_id)
	 * REFERENCES Consumers(consumer_id))");
	 **/

	String query = "SELECT consumer_id from consumers where customer_id =? and isActive = 1";
	ps = cn.prepareStatement(query);
	ps.setLong(1, cid);

	ResultSet rs;

	rs = ps.executeQuery();

	while (rs.next()) {

		// consumer_id bigint PRIMARY KEY,customer_id bigint NOT NULL,
		// address VARCHAR(255) NOT NULL,contact_number VARCHAR(15) NOT NULL,
		// customer_type VARCHAR(20) CHECK (customer_type IN ('Residential',
		// 'Commercial')) NOT NULL,FOREIGN
		consId.add(rs.getLong("consumer_id"));
	}
	DBUtil.toClose(cn, ps, rs);
	return consId;

}

	public int deleteConsumerByConsumerId(String consumerId) throws SQLException {
		Connection cn = DBUtil.toConnect();

		PreparedStatement ps = null;
		long cId;
		if(consumerId == null) {
			return 0;
		}
		else {
			cId = Long.parseLong(consumerId);
		}
		String query = "update consumers set isActive = 0 where consumer_id = ?";
		ps = cn.prepareStatement(query);
		ps.setLong(1, cId);
		int res = ps.executeUpdate();
		DBUtil.toClose(cn, ps, null);
		return res;
	}

	public int updateConsumer(Consumer cons) throws SQLException {
		Connection cn = DBUtil.toConnect();

		PreparedStatement ps = null;

		//consumer_id bigint PRIMARY KEY,customer_id bigint NOT NULL,
//		address VARCHAR(255) NOT NULL,contact_number VARCHAR(15) NOT NULL,
//		customer_type VARCHAR(20) CHECK (customer_type IN ('Residential', 'Commercial')) NOT NULL,FOREIGN KEY (customer_id) REFERENCES Customers(customer_id))");
//		
		String query = "update consumers set address = ?, contact_number = ?, customer_type = ? where consumer_id = ? AND customer_id = ?";
		
//		String query = "update consumers set address = ?, contact_number = ?, customer_type = ? where consumer_id = ?";

		ps = cn.prepareStatement(query);
		ps.setString(1, cons.getAddress());
		ps.setString(2, cons.getMobileNumber());
		ps.setString(3, cons.getCustomerType());
		ps.setLong(4, cons.getConsumerId());
		ps.setLong(5, cons.getCustomerId());

		int res = ps.executeUpdate();

		DBUtil.toClose(cn, ps, null);
		return res;
	}

}
