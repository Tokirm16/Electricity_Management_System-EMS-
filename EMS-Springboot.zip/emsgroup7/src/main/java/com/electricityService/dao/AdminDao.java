package com.electricityService.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.electricityService.bean.Admin;
import com.electricityService.bean.Complaint;
import com.electricityService.bean.Consumer;
import com.electricityService.bean.Customer;
import com.electricityService.service.CustomerService;
import com.electricityService.util.DBUtil;

public class AdminDao {

	// method to login
	public Admin login(String userId, String password) throws SQLException {

		Connection cn = DBUtil.toConnect();
		Admin admin = new Admin();

		PreparedStatement ps = cn.prepareStatement("select * from admins where user_id=? and password =?");
		ps.setString(1, userId);
		ps.setString(2, password);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			admin = new Admin(rs.getLong("admin_id"), rs.getString("name"), rs.getString("user_id"));
		}
		if (admin.getAdminId() == 0)
			return null;
		DBUtil.toClose(cn, ps, rs);
		return admin;
	}

	
	// method to add new customer
	public int addNewCustomer(Customer c) throws SQLException {

		String customer_id = CustomerService.generateUniqueID();
		int res = 0;
		
		Connection cn = DBUtil.toConnect();
		PreparedStatement ps = cn.prepareStatement("insert into Customers values (?,?,?,?,?,?,?,?)");
		ps.setLong(1, Long.parseLong(customer_id));
		ps.setString(2, c.getName());
		ps.setString(3, c.getAddress());
		ps.setString(4, c.getEmail());
		ps.setString(5, c.getMobileNumber());
		ps.setString(6, c.getCustomerType());
		ps.setString(7, c.getUserId());
		ps.setString(8, "Password@123");
		res = ps.executeUpdate();

		DBUtil.toClose(cn, ps, null);
		return res;
	}

	
	// method to add new Consumer for Admin
	public int addNewConsumer(Consumer cons) throws SQLException {

		Connection cn = DBUtil.toConnect();
		int inserted = 0;

		PreparedStatement ps = cn.prepareStatement("Insert into Consumers(consumer_id, customer_id, address, contact_number, customer_type) Values(?, ?, ?, ?, ?)");
		ps.setLong(1, cons.getConsumerId());
		ps.setLong(2, cons.getCustomerId());
		ps.setString(3, cons.getAddress());
		ps.setString(4, cons.getMobileNumber());
		ps.setString(5, cons.getCustomerType());

		inserted = ps.executeUpdate();
		DBUtil.toClose(cn, ps, null);
		return inserted;
	}

	
	
	// method to fetch complaint
	public ArrayList<Complaint> fetch() throws SQLException {

		Connection cn = DBUtil.toConnect();
		ArrayList<Complaint> complaints = new ArrayList<>();

		PreparedStatement ps = cn.prepareStatement("select * from Complaints");
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			String rsTime = "";
			if (rs.getDate("resolution_time") != null) {
				rsTime = rs.getDate("resolution_time").toString();
			} else {
				rsTime = "Not Resolved";
			}
			complaints.add(new Complaint(rs.getInt("complaint_id"), rs.getLong("consumer_id"),
					rs.getString("complaint_type"), rs.getString("category"), rs.getString("description"),
					rs.getString("landmark"), rs.getString("mobile_number"),
					(rs.getTimestamp("date_registered")).toString(), rs.getString("status"), rsTime));
		}
		DBUtil.toClose(cn, ps, rs);
		return complaints;
	}

}
