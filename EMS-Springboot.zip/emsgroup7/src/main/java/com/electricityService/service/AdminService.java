package com.electricityService.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.electricityService.bean.Admin;
import com.electricityService.bean.Bill;
import com.electricityService.bean.Complaint;
import com.electricityService.bean.Consumer;
import com.electricityService.bean.Customer;
import com.electricityService.controller.ResponseAddNewConsumer;
import com.electricityService.dao.AdminDao;
import com.electricityService.dao.BillDao;
import com.electricityService.dao.ConsumerDao;
import com.electricityService.dao.CustomerDao;

public class AdminService {

	// method to validate login credentials:(userId and password)
	public Admin login(String adminId, String password) {
		AdminDao dao = new AdminDao();
		Admin admin = new Admin();
		try {
			admin = dao.login(adminId, password);

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return admin;
	}

	
	// method to add bill
	public String addBill(Bill bill) {

		BillDao billdao = new BillDao();
		String bill_id = "";
		try {
			bill_id = billdao.addBill(bill);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return bill_id;
	}

	
	// method to get all consumers with the specific customerId
	public ArrayList<Consumer> getAllConsumer(String customer_id) {

		ConsumerDao consumerDao = new ConsumerDao();

		ArrayList<Consumer> consumers = new ArrayList<>();
		try {
			consumers = consumerDao.getAllConsumer(customer_id);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return consumers;
	}
	
	
	// method to delete the consumer with the consumerId
	public int deleteConsumerByConsumerId(String consumerId) {

		ConsumerDao consumerDao = new ConsumerDao();
		int isDeleted = 0;

		try {
			isDeleted = consumerDao.deleteConsumerByConsumerId(consumerId);
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return isDeleted;
	}

	
	// method to update consumer 
	public int updateConsumer(Consumer cons) {

		ConsumerDao consumerDao = new ConsumerDao();
		int isUpdated = 0;

		try {
			isUpdated = consumerDao.updateConsumer(cons);
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return isUpdated;
	}

	
	// method to get all bills
	public ArrayList<Bill> getAllBills() {
		// TODO Auto-generated method stub
		BillDao billDao = new BillDao();
		ArrayList<Bill> bills = new ArrayList<>();

		try {
			bills = billDao.getAllBills();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bills;
	}

	
	// method to get all consumerIds of a specific customer by customerId
	public ArrayList<Long> getAllConsumerId(String customerId) {

		ConsumerDao consumerDao = new ConsumerDao();

		ArrayList<Long> consumerId = new ArrayList<>();
		try {
			consumerId = consumerDao.getAllConsumerId(customerId);
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return consumerId;
	}

	
	// for Add New Consumer in Admin
	public ResponseAddNewConsumer getAllConsumersWithCustomer(String search_criteria) {

		CustomerDao dao = new CustomerDao();
		ResponseAddNewConsumer res = null;

		try {
			res = dao.getAllConsumersWithCustomer(search_criteria);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return res;

	}

	
	// method to Add new consumer 
	public int addNewConsumer(Consumer cons) {
		
		AdminDao dao = new AdminDao();

		int inserted = 0;
		try {
			inserted = dao.addNewConsumer(cons);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return inserted;
	}

	
	// method to add new customer
	public int addNewCustomer(Customer cust) {

		AdminDao dao = new AdminDao();

		int inserted = 0;
		try {
			inserted = dao.addNewCustomer(cust);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return inserted;
	}

	
	
	// ======================================
	// view complaint for admin
	public ArrayList<Complaint> fetch() {
		ArrayList<Complaint> complaints = new ArrayList<Complaint>();
		AdminDao dao = new AdminDao();
		try {
			complaints = dao.fetch();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return complaints;
	}

	// method to get all consumers
		public ArrayList<Consumer> getAllConsumer() {

			ConsumerDao consumerDao = new ConsumerDao();

			ArrayList<Consumer> consumers = new ArrayList<>();
			try {
				consumers = consumerDao.getAllConsumer();
			} catch (SQLException e) {

				e.printStackTrace();
			}
			return consumers;
		}
}
