package com.electricityService.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.electricityService.controller.PaymentRequestDto;
import com.electricityService.dao.BillDao;

public class PaymentService {

	public List<String> processPayment(PaymentRequestDto paymentRequest) {

		BillDao billdao = new BillDao();
		
		List<String> payDet = new ArrayList<>();
		try {
			payDet = billdao.processPayment(paymentRequest);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return payDet;
	}

}
