package com.electricityService.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.UUID;

import com.electricityService.bean.Bill;
import com.electricityService.bean.Complaint;
import com.electricityService.bean.Customer;

import com.electricityService.dao.BillDao;
import com.electricityService.dao.ComplaintDao;
import com.electricityService.dao.CustomerDao;

public class CustomerService {

	// **** method to generate 13 digit unique ids
	public static String generateUniqueID() {
		long timestamp = System.currentTimeMillis();
		String randomPart = UUID.randomUUID().toString().substring(0, 8);
		String uniqueID = timestamp + randomPart;
		return uniqueID.substring(0, 13);
	}
	// **** method to generate 6 digit unique 
	public static String generateCompID() {
		long timestamp = System.currentTimeMillis();
		String randomPart = UUID.randomUUID().toString().substring(0, 9);
		String uniqueID = timestamp + randomPart;
		return uniqueID.substring(5, 11);
	}


	// method to validate login credentials for customer or admin
	public Customer login(String userId, String password) {

		CustomerDao customerDao = new CustomerDao();
		Customer customer = null;
		try {
			customer = customerDao.login(userId, password);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return customer;
	}

	
	// method for inserting values into customer table
	public String registerCustomer(Customer customer) {
		CustomerDao customerDao = new CustomerDao();
		String customer_id = "";
		try {
			customer_id = customerDao.insertValues(customer);

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return customer_id;
	}


	// method to get current bill summary
	public Bill getCurrentBillSummary(String customer_id) {

		if (customer_id == null || customer_id.trim().isEmpty()) {
			throw new IllegalArgumentException("Cutomer ID can't be null or empty");
		}
		BillDao billdao = new BillDao();
		Bill bill = null;

		try {
			bill = billdao.getCurrentBillSummary(customer_id);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return bill;
	}

	
	// method to add complaint
	public String registerComplaint(Complaint complaint) {

		ComplaintDao compdao = new ComplaintDao();

		String comp = "";
		try {
			comp = compdao.registerComplaint(complaint);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return comp;

	}

	// method to view complaint by customerId
	public ArrayList<Complaint> viewComplaints(String customer_id) {
		
		if (customer_id == null || customer_id.trim().isEmpty()) {
			throw new IllegalArgumentException("Cutomer ID can't be null or empty");
		}
		ComplaintDao complaintdao = new ComplaintDao();
		ArrayList<Complaint> complaints = new ArrayList<>();
		try {
			complaints = complaintdao.viewComplaints(customer_id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return complaints;
	}

	
	
	
	// =================================================================
	// method for search credentials:(userId and name)
		public Customer search(String search_criteria) {
			CustomerDao dao = new CustomerDao();
			Customer customer = new Customer();
			try {
				customer = dao.search(search_criteria);

			} catch (SQLException e) {

				e.printStackTrace();
			}
			return customer;
		}
	
		// method to fetch the arraylist of bills
		public ArrayList<Bill> getAllBillsOfConsumer(String customer_id) {

			BillDao billdao = new BillDao();
			ArrayList<Bill> bills = new ArrayList<>();
			try {
				bills = billdao.getAllBillsOfConsumer(customer_id);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return bills;
		}
		// method to fetch the arraylist of Paid bills
				public ArrayList<Bill> viewPaidBillByCustId(String customer_id) {

					BillDao billdao = new BillDao();
					ArrayList<Bill> bills = new ArrayList<>();
					try {
						bills = billdao.viewPaidBillByCustId(customer_id);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return bills;
				}
}
