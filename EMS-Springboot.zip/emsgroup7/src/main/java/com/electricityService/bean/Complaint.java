package com.electricityService.bean;
public class Complaint {
	 
		 private int complaintId;
		 private long consumerId;
		 private String complaintType;
		 private String category;
		 private String description;
		 private String landmark;
		 private String mobileNumber;
		 private String dateRegistered;
		 private String status;
		 private String resolutinTime;
		public int getComplaintId() {
			return complaintId;
		}
		public void setComplaintId(int complaintId) {
			this.complaintId = complaintId;
		}
		public long getConsumerId() {
			return consumerId;
		}
		public void setConsumerId(long consumerId) {
			this.consumerId = consumerId;
		}
		public String getComplaintType() {
			return complaintType;
		}
		public void setComplaintType(String complaintType) {
			this.complaintType = complaintType;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getLandmark() {
			return landmark;
		}
		public void setLandmark(String landmark) {
			this.landmark = landmark;
		}
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public String getDateRegistered() {
			return dateRegistered;
		}
		public void setDateRegistered(String dateRegistered) {
			this.dateRegistered = dateRegistered;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getResolutinTime() {
			return resolutinTime;
		}
		public void setResolutinTime(String resolutinTime) {
			this.resolutinTime = resolutinTime;
		}
		public Complaint(int complaintId, long consumerId, String complaintType, String category, String description,
				String landmark, String mobileNumber, String dateRegistered, String status, String resolutinTime) {
			super();
			this.complaintId = complaintId;
			this.consumerId = consumerId;
			this.complaintType = complaintType;
			this.category = category;
			this.description = description;
			this.landmark = landmark;
			this.mobileNumber = mobileNumber;
			this.dateRegistered = dateRegistered;
			this.status = status;
			this.resolutinTime = resolutinTime;
		}
		 
		 public Complaint() {
			 
		 }
//		 complaintId, consumerId, complaintType, category, description, landmark, mobile_number, status
			public Complaint(int complaintId, long consumerId, String complaintType, String category, String description,
					String landmark, String mobileNumber, String status) {
				super();
				this.complaintId = complaintId;
				this.consumerId = consumerId;
				this.complaintType = complaintType;
				this.category = category;
				this.description = description;
				this.landmark = landmark;
				this.mobileNumber = mobileNumber;
				this.status = status;
			
			}
		 
//		 b.complaint_id, b.consumer_id, b.complaint_type, b.status, b.date_registered, b.resoltion_time
		 public Complaint(int complaint_id, long consumer_id, String complaint_type, String status, String date_registered, String resoltion_time) {
			 this.complaintId = complaint_id;
			 this.consumerId = consumer_id;
			 this.complaintType = complaint_type;
			 this.status = status;
			 this.dateRegistered = date_registered;
			 this.resolutinTime = resoltion_time;
		 }

}
