package com.electricityService.bean;

public class Bill {
	
	private long billNumber;
	private long consumerId;
	private String billDate;
	private String dueDate;
	private double billAmount;
	private double payableAmount;
	private int paymentStatus;
	private String paymentDate;
	private double electricityUsage;
	private String paymentMode;
	
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public long getBillNumber() {
		return billNumber;
	}
	public void setBillNumber(long billNumber) {
		this.billNumber = billNumber;
	}
	public long getConsumerId() {
		return consumerId;
	}
	public void setConsumerId(long consumerId) {
		this.consumerId = consumerId;
	}
	public String getBillDate() {
		return billDate;
	}
	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public double getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}
	public double getPayableAmount() {
		return payableAmount;
	}
	public void setPayableAmount(double payableAmount) {
		this.payableAmount = payableAmount;
	}
	public int getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(int paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	
	public double getElectricityUsage() {
		return electricityUsage;
	}
	public void setElectricityUsage(double electricityUsage) {
		this.electricityUsage = electricityUsage;
	}
	
	// -----for add bill
//	billNumber, consumerId, billDate, dueDate, billAmount, payableAmount, paymentStatus, electricityUsage
	public Bill(long billNumber, long consumerId, String billDate, String dueDate, double billAmount,
			double payableAmount, int paymentStatus, double electricityUsage) {
		super();
		this.billNumber = billNumber;
		this.consumerId = consumerId;
		this.billDate = billDate;
		this.dueDate = dueDate;
		this.billAmount = billAmount;
		this.payableAmount = payableAmount;
		this.paymentStatus = paymentStatus;
//		this.paymentDate = paymentDate;
		this.electricityUsage = electricityUsage;
	}
	
	
//	for view Paid bills , with paymentDate -- bill history 
	public Bill(long billNumber, long consumerId, String billDate, String dueDate, double billAmount,
			double payableAmount, int paymentStatus, String paymentDate, String paymentMode, double electricityUsage) {
		super();
		this.billNumber = billNumber;
		this.consumerId = consumerId;
		this.billDate = billDate;
		this.dueDate = dueDate;
		this.billAmount = billAmount;
		this.payableAmount = payableAmount;
		this.paymentStatus = paymentStatus;
		this.paymentDate = paymentDate;
		this.paymentMode = paymentMode;
		this.electricityUsage = electricityUsage;
	}
	
	
	public Bill() {
		
	}
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

//	bill = new Bill(rs.getLong("bill_number"),  rs.getString("bill_date"), rs.getString("due_date"), rs.getDouble("bill_amount"), rs.getDouble("payable_amount")));
	
	public Bill(long bill_number, String bill_date, String due_date, double bill_amount, double payable_amount) {
		this.billNumber = bill_number;
		this.billDate = bill_date;
		this.billAmount = bill_amount;
		this.payableAmount = payable_amount;
	}
	
}
