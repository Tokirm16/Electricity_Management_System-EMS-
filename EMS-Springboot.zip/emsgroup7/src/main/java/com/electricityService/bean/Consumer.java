package com.electricityService.bean;

public class Consumer {
	
	private long consumerId;
	private long customerId;
	private String address;
	private String mobileNumber;
	private String customerType;
	
	public long getConsumerId() {
		return consumerId;
	}
	public void setConsumerId(long consumerId) {
		this.consumerId = consumerId;
	}
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public Consumer(long consumerId, long customerId, String address, String mobileNumber, String customerType) {
		super();
		this.consumerId = consumerId;
		this.customerId = customerId;
		this.address = address;
		this.mobileNumber = mobileNumber;
		this.customerType = customerType;
	}
	
	public Consumer() {
		
	}
	@Override
	public String toString() {
		return "Consumer [consumerId=" + consumerId + ", customerId=" + customerId + ", address=" + address
				+ ", mobileNumber=" + mobileNumber + ", customerType=" + customerType + "]";
	}



}
