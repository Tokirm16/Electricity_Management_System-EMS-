package com.electricityService.bean;

public class Payment {
	
	private long paymentId;
	private long billNumber;
	private String paymentDate;
	private String paymentMode;
	private long transactionId;
	private double paymentAmount;
	public long getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(long paymentId) {
		this.paymentId = paymentId;
	}
	public long getBillNumber() {
		return billNumber;
	}
	public void setBillNumber(long billNumber) {
		this.billNumber = billNumber;
	}
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public double getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public Payment(long paymentId, long billNumber, String paymentDate, String paymentMode, long transactionId,
			double paymentAmount) {
		super();
		this.paymentId = paymentId;
		this.billNumber = billNumber;
		this.paymentDate = paymentDate;
		this.paymentMode = paymentMode;
		this.transactionId = transactionId;
		this.paymentAmount = paymentAmount;
	}
	
	public Payment() {
		
	}
	
}
