package com.electricityService.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtil {
	public DBUtil() {
	}

	public static Connection toConnect() {
		try {
			Connection cn = null;
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			cn = DriverManager.getConnection("jdbc:derby:C:\\Users\\2784476\\Music\\emsgroup7\\Electricity_Database;create=true");
//			cn = DriverManager.getConnection("jdbc:derby:C:\\Users\\mohd. tokir\\Downloads\\emsgroup7\\emsgroup7\\Electricity_Database;create=true");
			return cn;
		} catch (Exception var1) {
			var1.printStackTrace();
			return null;
		}
	}

	public static void toClose(Connection cn, PreparedStatement ps, ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException var6) {
				var6.printStackTrace();
			}
		}

		if (ps != null) {
			try {
				ps.close();
			} catch (SQLException var5) {
				var5.printStackTrace();
			}
		}

		if (cn != null) {
			try {
				cn.close();
			} catch (SQLException var4) {
				var4.printStackTrace();
			}
		}

	}

	public static void main(String[] args) throws SQLException {

		Connection cn = DBUtil.toConnect();
//		PreparedStatement ps = cn.prepareStatement(
//				"CREATE TABLE Customers (customer_id bigint PRIMARY KEY,name VARCHAR(50) NOT NULL,address VARCHAR(255) NOT NULL,email VARCHAR(100) UNIQUE NOT NULL,mobile_number VARCHAR(15) NOT NULL,customer_type VARCHAR(20)  not null CHECK (customer_type IN('Residential','Commercial')) NOT NULL,user_id VARCHAR(20) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL)");
//		int res = ps.executeUpdate();
//		ps = cn.prepareStatement(
//				"CREATE TABLE Consumers (consumer_id bigint PRIMARY KEY,customer_id bigint NOT NULL,address VARCHAR(255) NOT NULL,contact_number VARCHAR(15) NOT NULL,customer_type VARCHAR(20) CHECK (customer_type IN ('Residential', 'Commercial')) NOT NULL,FOREIGN KEY (customer_id) REFERENCES Customers(customer_id))");
//		res = ps.executeUpdate();
//		ps = cn.prepareStatement(
//				"CREATE TABLE Bills (bill_number bigint primary key, consumer_id bigint, bill_date DATE NOT NULL, due_date DATE NOT NULL, bill_amount DECIMAL(10, 2) NOT NULL, payable_amount DECIMAL(10, 2) NOT NULL, payment_status int default 0,pg_charge REAL,electricity_usage REAL NOT NULL DEFAULT 0.02,FOREIGN KEY (consumer_id) REFERENCES Consumers(consumer_id))");
//		res = ps.executeUpdate();
//		ps = cn.prepareStatement(
//				"CREATE TABLE Payments (payment_id BigINT PRIMARY KEY,bill_number BIGINT NOT NULL,payment_date DATE NOT NULL,payment_mode VARCHAR(20) CHECK (payment_mode IN ('Credit Card', 'Debit Card', 'Net Banking')) NOT NULL,transaction_id VARCHAR(50) UNIQUE NOT NULL,payment_amount DECIMAL(10, 2) NOT NULL,FOREIGN KEY (bill_number) REFERENCES Bills(bill_number))");
//		res = ps.executeUpdate();
//		ps = cn.prepareStatement(
//				"CREATE TABLE Complaints (complaint_id INT  PRIMARY KEY, consumer_id bigINT NOT NULL, complaint_type VARCHAR(50) NOT NULL, category VARCHAR(50) NOT NULL, description VARCHAR(255) NOT NULL, landmark varchar(255), mobile_number VARCHAR(15) NOT NULL ,date_registered TIMESTAMP DEFAULT CURRENT_TIMESTAMP,status VARCHAR(20) CHECK (status IN ('Pending', 'In Progress', 'Resolved', 'Closed')) NOT NULL,resolution_time DATE,FOREIGN KEY (consumer_id) REFERENCES Consumers(consumer_id))");
//		res = ps.executeUpdate();
//		ps = cn.prepareStatement(
//				"CREATE TABLE Admins (admin_id INT  PRIMARY KEY, name VARCHAR(50) NOT NULL, user_id VARCHAR(20) UNIQUE NOT NULL,password VARCHAR(255) NOT NULL)");
//		res = ps.executeUpdate();
		//PreparedStatement ps = null;

//		ps = cn.prepareStatement("INSERT INTO Customers (customer_id, name, address, email, mobile_number, customer_type, user_id, password) \r\n"
//				+ "		VALUES (11, 'Isha', '123 Main Street, NY', 'isha.doe@gmail.com', '9034567890', 'Residential', 'isha@123', 'Admin@123')");
//		int res = ps.executeUpdate();
//		
//		ps = cn.prepareStatement("INSERT INTO Customers (customer_id, name, address, email, mobile_number, customer_type, user_id, password) "
//				+ "VALUES (22, 'Leo', '45 Elm Street, LA', 'leo.smith@yahoo.com', '9876943210', 'Commercial', 'Leo@123', 'Admin@123')");
//		res = ps.executeUpdate();
//		
//		ps = cn.prepareStatement("INSERT INTO Customers (customer_id, name, address, email, mobile_number, customer_type, user_id, password) \r\n"
//				+ "		VALUES (33, 'Suri', '789 Oak Avenue, Chicago', 'suri.brown@outlook.com', '7761237890', 'Residential', 'Suri@123', 'Admin@123')");
//		res = ps.executeUpdate();

////		Insert Consumer 1 for Customer 1
//		ps = cn.prepareStatement("INSERT INTO Consumers (consumer_id, customer_id, address, contact_number, customer_type) VALUES (101, 1, '123 Main Street, NY', '1234567890', 'Residential')");
//		int res = ps.executeUpdate();
////		Insert Consumer 2 for Customer 1
//		ps = cn.prepareStatement("INSERT INTO Consumers (consumer_id, customer_id, address, contact_number, customer_type) VALUES (102, 1, '456 Oak Street, NY', '2345678901', 'Residential')");
//		res = ps.executeUpdate();
////		Insert Consumer 3 for Customer 2
		
		//1733395290575-------------------------------- bill no for consId : 123123 
//		ps = cn.prepareStatement("INSERT INTO Consumers (consumer_id, customer_id, address, contact_number, customer_type) VALUES (123123, 1733379588859, '78 Elm Street, LA', '6256789012', 'Commercial')");
//	PreparedStatement ps = cn.prepareStatement("INSERT INTO Consumers (consumer_id, customer_id, address, contact_number, customer_type) VALUES (114114, 22, '78 Elm Street, LA', '6256989012', 'Commercial')");
		
//		int res = ps.executeUpdate();
		
		//ps = cn.prepareStatement("alter table Consumers add column isActive int default 1");
////		Insert Consumer 4 for Customer 2
//		ps = cn.prepareStatement("INSERT INTO Consumers (consumer_id, customer_id, address, contact_number, customer_type) VALUES (104, 2, '98 Birch Lane, LA', '4567890123', 'Commercial')");
//		res = ps.executeUpdate();
////		Insert Consumer 5 for Customer 3
//		ps = cn.prepareStatement("INSERT INTO Consumers (consumer_id, customer_id, address, contact_number, customer_type) VALUES (105, 3, '789 Oak Avenue, Chicago', '5678901234', 'Residential')");
//		res = ps.executeUpdate();

////		-- Insert Bill for Consumer 1 (Customer 1)
//		ps = cn.prepareStatement("INSERT INTO Bills (bill_number, consumer_id, bill_date, due_date, bill_amount, payable_amount, payment_status, pg_charge, electricity_usage) VALUES (1001, 101, '2024-11-01', '2024-11-15', 120.50, 120.50, 0, 3.50, 0.02)");
//		int res = ps.executeUpdate();
////		-- Insert Bill for Consumer 2 (Customer 1)
//		ps = cn.prepareStatement("INSERT INTO Bills (bill_number, consumer_id, bill_date, due_date, bill_amount, payable_amount, payment_status, pg_charge, electricity_usage) VALUES (1002, 102, '2024-11-01', '2024-11-15', 150.75, 150.75, 0, 4.00, 0.03)");
//		res = ps.executeUpdate();
////		-- Insert Bill for Consumer 3 (Customer 2)
//		ps = cn.prepareStatement("INSERT INTO Bills (bill_number, consumer_id, bill_date, due_date, bill_amount, payable_amount, payment_status, pg_charge, electricity_usage) VALUES (1003, 103, '2024-11-05', '2024-11-20', 250.75, 250.75, 0, 5.00, 0.04)");
//		res = ps.executeUpdate();
////		-- Insert Bill for Consumer 4 (Customer 2)
//		ps = cn.prepareStatement("INSERT INTO Bills (bill_number, consumer_id, bill_date, due_date, bill_amount, payable_amount, payment_status, pg_charge, electricity_usage) VALUES (1004, 104, '2024-11-10', '2024-11-25', 300.00, 300.00, 0, 6.00, 0.05)");
//		res = ps.executeUpdate();
////		-- Insert Bill for Consumer 5 (Customer 3)
//		ps = cn.prepareStatement("INSERT INTO Bills (bill_number, consumer_id, bill_date, due_date, bill_amount, payable_amount, payment_status, pg_charge, electricity_usage) VALUES (1005, 105, '2024-11-15', '2024-11-30', 175.80, 175.80, 0, 4.50, 0.03)");
//		res = ps.executeUpdate();


//		ps = cn.prepareStatement(
//				"insert into Admins (admin_id , name , user_id ,password) values(100,'admin','admin','admin')");
//		int adm = ps.executeUpdate();

//		System.out.println("completed: res= " + res);
	}
	
}
