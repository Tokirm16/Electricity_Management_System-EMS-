package com.electricityService.controller;

public class PaymentRequestDto {

	private String paymentMode; // Payment mode: Credit Card, Debit Card, UPI, Net Banking

//  private List<Long> billNumbers; // List of bill numbers to be paid

	private long billNumber;
	private double payableAmount; // Total amount to be paid

	// Getters and Setters

	public String getPaymentMode() {

		return paymentMode;

	}

	public void setPaymentMode(String paymentMode) {

		this.paymentMode = paymentMode;

	}

	public long getBillNumber() {

		return billNumber;

	}

	public void setBillNumber(long billNumbers) {

		this.billNumber = billNumbers;

	}

	public double getPayableAmount() {

		return payableAmount;

	}

	public void setPayableAmount(double payableAmount) {

		this.payableAmount = payableAmount;

	}

	@Override
	public String toString() {
		return "PaymentRequestDto [paymentMode=" + paymentMode + ", billNumber=" + billNumber + ", payableAmount="
				+ payableAmount + "]";
	}

}