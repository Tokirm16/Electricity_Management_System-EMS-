package com.electricityService.controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.electricityService.bean.Bill;
import com.electricityService.bean.Complaint;
import com.electricityService.bean.Consumer;
import com.electricityService.bean.Customer;
import com.electricityService.service.AdminService;
import com.electricityService.service.CustomerService;
import com.google.gson.Gson;

@RestController
@RequestMapping("/apiAdmin")
public class AdminController {

	// Endpoint to add bills 
	@PostMapping("/addBill")
	public String addBill(@RequestBody Bill bill) {
		AdminService adminservice = new AdminService();
		String bill_id = "";
		try {
			bill_id = adminservice.addBill(bill);

		} catch (Exception e) {
			e.printStackTrace();
		}
		Gson gson = new Gson();
		if (bill_id == null)
			return gson.toJson("Failed to Add Bill!!!");

		return gson.toJson("Bill Added Successfuly. Bill Number: " + bill_id);

	}

	
	// Endpoint to Get All ConsumerId by CustomerId
	@GetMapping("/getAllConsumerId/{customerId}")
	public String getAllConsumerId(@PathVariable String customerId) {
		AdminService adminservice = new AdminService();
		ArrayList<Long> consumerId = new ArrayList<>();
		consumerId = adminservice.getAllConsumerId(customerId);
		Gson gson = new Gson();
		if (consumerId.isEmpty()) {
			return (gson.toJson("No Consumer Found!"));
		}
		return gson.toJson(consumerId);

	}

	
	// Endpoint to remove consumer by consumerId
	@DeleteMapping("/deleteConsumer/{consumerId}")
	public String deleteConsumerByConsumerId(@PathVariable String consumerId) {
		AdminService adminservice = new AdminService();

		int isDeleted = 0;

		isDeleted = adminservice.deleteConsumerByConsumerId(consumerId);
		Gson gson = new Gson();
		if (isDeleted == 0) {
			return (gson.toJson("Cannot Delete Consumer!"));
		}
		return gson.toJson("Consumer deleted Successfully!");
	}

	
	
	// Endpoint to update consumer 
	@PatchMapping("/updateConsumer")
	public String updateConsumer(@RequestBody Consumer cons) {
		AdminService adminservice = new AdminService();

		System.out.println(cons + "-------------------");
		int isUpdated = 0;
		isUpdated = adminservice.updateConsumer(cons);
		Gson gson = new Gson();
		if (isUpdated == 0) {
			return (gson.toJson("Cannot Update Consumer!"));
		}
		return gson.toJson("Consumer details Updated Successfully!");
	}
	
	
	
	//	Endpoint to fetch Customer details along with consumerId
	@GetMapping("/getAllConsumersWithCustomer/{search_criteria}")
	public String getAllConsumersWithCustomer(@PathVariable String search_criteria) {
		AdminService adminservice = new AdminService();

		ResponseAddNewConsumer rs = adminservice.getAllConsumersWithCustomer(search_criteria);

		Gson gson = new Gson();
		if (rs == null) {
			return (gson.toJson("No Customer Found!"));
		}
		return gson.toJson(rs);
	}
	
	
	
	// Endpoint to add new consumer
	@PostMapping("/addNewConsumer")
	public String addNewConsumer(@RequestBody Consumer cons) {
		AdminService adminservice = new AdminService();

		System.out.println("------------" + cons + "------------");

		int inserted = 0;
		inserted = adminservice.addNewConsumer(cons);

		Gson gson = new Gson();
		if (inserted == 0) {
			return (gson.toJson("Cannot Add Consumer!"));
		}
		return gson.toJson("Consumer Added Successfully!");
	}
	
	
	
	// Enndpoint to add new Customer
	@PostMapping("/addNewCustomer")
	public String addNewCustomer(@RequestBody Customer cust) {

		AdminService adminservice = new AdminService();

		int rs = adminservice.addNewCustomer(cust);

		Gson gson = new Gson();
		if (rs == 0) {
			return (gson.toJson("Customer Insertion Failed!"));
		}
		return gson.toJson("Customer Added Successfully.");

	}

	//Endpoint to view bills for all consumers in Admin
			@GetMapping("/viewBill")
			public String viewBill() {
				AdminService adminService = new AdminService();
				// String bill_as_json = "";

				ArrayList<Bill> bills = new ArrayList<>();

				bills = adminService.getAllBills();

				Gson gson = new Gson();

				String bill_as_json = gson.toJson(bills);

				if (bills.size() == 0) {
					return (gson.toJson("No Bill Found!"));
				}
				return bill_as_json;
		}
	
	
	
	
	
// ===========================method for search credentials:(userId and name)
@GetMapping("/search/{search_criteria}")
public String searchCustomer(@PathVariable String search_criteria) {
	
	CustomerService service = new CustomerService();
	
	Customer customer = service.search(search_criteria);
	
	Gson gson = new Gson();
	if (customer == null)
		return gson.toJson("No Customer Found!!!");
	
	return gson.toJson(customer);
}

	// ======================================================
	@GetMapping("/fetchComplaint")
	public String fetchComplaint() {
		AdminService adminservice = new AdminService();
		ArrayList<Complaint> complaints = new ArrayList<>();
		complaints = adminservice.fetch();
		Gson gson = new Gson();
		if (complaints.isEmpty()) {
			return (gson.toJson("No Complaints Found!"));
		}
		return gson.toJson(complaints);

	}

	// ============================================
	@GetMapping("/getAllConsumers/{customerId}")
	public String getAllConsumers(@PathVariable String customerId) {
		AdminService adminservice = new AdminService();
		ArrayList<Consumer> consumers = new ArrayList<>();
		consumers = adminservice.getAllConsumer(customerId);
		Gson gson = new Gson();
		if (consumers.isEmpty()) {
			return (gson.toJson("No Consumer Found!"));
		}
		return gson.toJson(consumers);

	}

	

//========================================================
		// update and search
		@GetMapping("/viewAllConsumers")
		public String viewAllConsumers() {
			AdminService adminservice = new AdminService();
			ArrayList<Consumer> consumers = new ArrayList<>();
			consumers = adminservice.getAllConsumer();
			Gson gson = new Gson();
			if (consumers.isEmpty()) {
				return (gson.toJson("No Consumer Found!"));
			}
			return gson.toJson(consumers);

		}
}