package com.electricityService.controller;

import java.util.ArrayList;

public class ResponseAddNewConsumer {

	private long customerId;
	private String name;
	private String address;
	private String email;
	private String mobileNumber;
	private String customerType;
	private String userId;
	private String password;
	
	private ArrayList<Long> AllConsumers = new ArrayList<>();

	
	
	public ResponseAddNewConsumer(long customerId, String name, String address, String email, String mobileNumber,
			String customerType, String userId, String password, ArrayList<Long> allConsumers) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.address = address;
		this.email = email;
		this.mobileNumber = mobileNumber;
		this.customerType = customerType;
		this.userId = userId;
		this.password = password;
		AllConsumers = allConsumers;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public ArrayList<Long> getAllConsumers() {
		return AllConsumers;
	}

	public void setAllConsumers(ArrayList<Long> allConsumers) {
		AllConsumers = allConsumers;
	}

	@Override
	public String toString() {
		return "ResponseAddNewConsumer [customerId=" + customerId + ", name=" + name + ", address=" + address
				+ ", email=" + email + ", mobileNumber=" + mobileNumber + ", customerType=" + customerType + ", userId="
				+ userId + ", password=" + password + ", AllConsumers=" + AllConsumers + "]";
	}
	
	
	
}
