package com.electricityService.controller;

import com.electricityService.bean.Admin;
import com.electricityService.bean.Customer;

import com.electricityService.service.AdminService;
import com.electricityService.service.CustomerService;
import com.google.gson.Gson;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class LoginController {

	// end point for login as a customer/admin
		@RequestMapping(method = RequestMethod.POST , value= "/login")
		public String login(@RequestBody LoginRequest loginRequest) {
			Gson gson = new Gson();
			
			String role = loginRequest.getRole();
			String userId = loginRequest.getUserId();
			String password = loginRequest.getPassword();
			
			if("admin".equals(role) && role!=null) {
				AdminService adminService = new AdminService();
				Admin admin = adminService.login(userId, password);
				if(admin == null) return (gson.toJson("Login Failed"));
				return(gson.toJson(admin));
				
			}else if("customer".equals(role) && role!=null) {
				CustomerService customerService = new CustomerService();
				Customer customer = customerService.login(userId, password);
				if(customer == null) return (gson.toJson("Login Failed"));
				return (gson.toJson(customer));
			}
			
			String statement = "Failed to Login:";
			return gson.toJson(statement);
		}

	
	
}
