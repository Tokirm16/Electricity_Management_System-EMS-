package com.electricityService.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.electricityService.bean.Bill;
import com.electricityService.bean.Complaint;
import com.electricityService.bean.Customer;
import com.electricityService.service.CustomerService;
import com.electricityService.service.PaymentService;
import com.google.gson.Gson;

@RestController
@RequestMapping("/api")
public class CustomerController {

	// Endpoint to register a new customer - tested
	@PostMapping("/customers/register")
	public String registerCustomer(@RequestBody Customer customer) {

		CustomerService customerService = new CustomerService();
		String customer_id = null;
		try {
			customer_id = customerService.registerCustomer(customer);

		} catch (Exception e) {
			e.printStackTrace();
		}
		Gson gson = new Gson();
		if (customer_id != null)
			return gson.toJson(customer_id);

		return gson.toJson("Customer Registration Failed!!!");

	}

	// Endpoint to view bills
	@GetMapping("/viewBill/{customer_id}")
	public String viewBillByCustId(@PathVariable String customer_id) {
		
		CustomerService customerService = new CustomerService();
		ArrayList<Bill> bills = customerService.getAllBillsOfConsumer(customer_id);
		
		Gson gson = new Gson();

		String bill_as_json = gson.toJson(bills);

		if (bills.isEmpty()) {
			return (gson.toJson("No Bill Found!"));
		}
		return bill_as_json;
	}
	
	// Endpoint to view Paid bills
		@GetMapping("/viewPaidBill/{customer_id}")
		public String viewPaidBillByCustId(@PathVariable String customer_id) {
			
			CustomerService customerService = new CustomerService();
			ArrayList<Bill> bills = customerService.viewPaidBillByCustId(customer_id);
			
			Gson gson = new Gson();

			String bill_as_json = gson.toJson(bills);

			if (bills.isEmpty()) {
				return (gson.toJson("No Bill Found!"));
			}
			return bill_as_json;
		}

	@GetMapping("/currentBillSummary/{customer_id}")
	public String currentBillSummary(@PathVariable String customer_id) {
		CustomerService customerService = new CustomerService();

		Bill bill = customerService.getCurrentBillSummary(customer_id);
		Gson gson = new Gson();
		String bill_as_json = gson.toJson(bill);

		if (bill == null) {
			return (gson.toJson("No Bill Summary Found!"));
		}
		return bill_as_json;
	}

	// Endpoint for processing Payment
	@PostMapping("/pay")
	public String processPayment(@RequestBody PaymentRequestDto paymentRequest) {

		// Example Logging

		System.out.println("Payment Mode: " + paymentRequest.getPaymentMode());

		System.out.println("BillNumber: " + paymentRequest.getBillNumber());

		System.out.println("Payable Amount: " + paymentRequest.getPayableAmount());

		// Process the payment (call a service to handle business logic)

		PaymentService payservice = new PaymentService();
		List<String> success = payservice.processPayment(paymentRequest);

		if (success.isEmpty())
			return "Payment Failed";

		Gson gson = new Gson();
		return gson.toJson(success);

	}

	// Endpoint for register complaint
	@PostMapping("/register/complaint")
	public String registerComplaint(@RequestBody Complaint complaint) {
		CustomerService customerService = new CustomerService();
		String compId = null;
		try {
			compId = customerService.registerComplaint(complaint);

		} catch (Exception e) {

			e.printStackTrace();
		}
		Gson gson = new Gson();
		if (compId == null)
			return gson.toJson("Registration failed!!!");

		return gson.toJson(compId);

	}

	// Endpoint to view complaint by customerId
	@GetMapping("/viewComplaint/{customerId}")
	public String viewComplaints(@PathVariable("customerId") String customer_id) {
		CustomerService customerService = new CustomerService();
		String comp_as_json = "";

		ArrayList<Complaint> complaints = customerService.viewComplaints(customer_id);
		Gson gson = new Gson();
		comp_as_json = gson.toJson(complaints);

		if (complaints.isEmpty()) {
			return (gson.toJson("No Complaint Found!"));
		}

		return comp_as_json;
	}

}
